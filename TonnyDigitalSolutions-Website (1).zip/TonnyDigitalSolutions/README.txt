TONNY DIGITAL SOLUTIONS WEBSITE
================================

FILES
- index.html: website content and sections
- style.css: colours, layout and mobile-friendly styling
- script.js: mobile navigation and current footer year

TEST THE WEBSITE ON YOUR COMPUTER
1. Extract the ZIP file if you downloaded it as a ZIP.
2. Open the TonnyDigitalSolutions folder.
3. Double-click index.html.
4. It should open in your web browser.
5. Click Home, About Us, Services and Contact Us to test the navigation.
6. Click a WhatsApp button to check that it opens WhatsApp with a prepared message.

IMPORTANT WHATSAPP NUMBER CHECK
The number you supplied was 0143470006. The website uses the Kenyan international format
254143470006 in its WhatsApp links (the leading 0 is removed and 254 is added).
Before publishing, verify that this is the correct number and that it is registered on WhatsApp.
If it is not correct, replace every occurrence of 254143470006 in index.html with the correct
country code and phone number, digits only.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new public repository, for example: tonny-digital-solutions
3. Upload index.html, style.css and script.js to the repository's main/root folder.
4. In the repository, open Settings -> Pages.
5. Under the build/deployment source, choose Deploy from a branch.
6. Choose the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish. The published address will be shown in Settings -> Pages.
8. Open that address on your phone and computer and test every menu link and WhatsApp button.

NOTES
- Hosting on GitHub Pages is free for a public repository, but you need an account.
- A custom domain name usually costs money; it is optional.
- This is a static website. It does not collect form submissions or store customer information.
- WhatsApp links need an internet connection and a WhatsApp account/app or WhatsApp Web.
